import { Component } from '@angular/core';

@Component({
  selector: 'app-root', //HTML TAG
  templateUrl: './app.component.html', //HTML
  styleUrls: ['./app.component.css'] //CSS
})
export class AppComponent {
  title = 'JigarAngularApp';
}

