import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ShrutiComponentComponent } from './shruti-component/shruti-component.component';
import { JigarDemoComponent } from './jigar-demo/jigar-demo.component';

import { FormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { ParentComponentComponent } from './parent-component/parent-component.component';
import { ChildComponentComponent } from './child-component/child-component.component';
import { ReactiveFormsModule } from '@angular/forms';
import { AngularHooksComponent } from './angular-hooks/angular-hooks.component';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { DemoDirectiveDirective } from './directive/demo-directive.directive';
import { HttpClientModule } from '@angular/common/http';
import {BaseService} from './services/base.service';

import {StrutiDemoService} from './services/struti-demo.service';

import { BackgroudDirectiveDirective } from './directive/backgroud-directive.directive';
import { ParentNikunjComponent } from './parent-nikunj/parent-nikunj.component';
import { ChildNikunjComponent } from './child-nikunj/child-nikunj.component';
import { MultiplyPipe } from './multiply.pipe';

import {CanAuthServiceService} from './service/can-auth-service.service';
import { NikunjDirectivesDirective } from './directive/nikunj-directives.directive';
import { NIkunjServiceService } from './services/nikunj-service.service';


@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    ShrutiComponentComponent,
    JigarDemoComponent,
    HeaderComponent,
    ParentComponentComponent,
    ChildComponentComponent,
    AngularHooksComponent,
    RegistrationFormComponent,
    DemoDirectiveDirective,
    BackgroudDirectiveDirective,
    ParentNikunjComponent,
    ChildNikunjComponent,
    MultiplyPipe,
    NikunjDirectivesDirective
  ],
  exports:[DemoDirectiveDirective],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [BaseService,StrutiDemoService,CanAuthServiceService,NIkunjServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
