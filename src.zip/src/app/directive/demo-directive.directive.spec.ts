import { DemoDirectiveDirective } from './demo-directive.directive';

describe('DemoDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new DemoDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
