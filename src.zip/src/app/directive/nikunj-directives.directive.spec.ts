import { NikunjDirectivesDirective } from './nikunj-directives.directive';

describe('NikunjDirectivesDirective', () => {
  it('should create an instance', () => {
    const directive = new NikunjDirectivesDirective();
    expect(directive).toBeTruthy();
  });
});
