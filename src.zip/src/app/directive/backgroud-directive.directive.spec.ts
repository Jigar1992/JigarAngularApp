import { BackgroudDirectiveDirective } from './backgroud-directive.directive';

describe('BackgroudDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new BackgroudDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
